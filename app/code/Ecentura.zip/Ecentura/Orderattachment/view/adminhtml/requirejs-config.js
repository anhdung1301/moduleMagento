var config = {
    map: {
        '*': {
            orderAttachment : 'Ecentura_Orderattachment/js/order-attachment'
        }
    }
};
